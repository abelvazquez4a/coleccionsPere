import java.time.LocalDate;

public class Bombeta implements Comparable<Bombeta> {
    private static int contador=1;
    private String nombre;
    private int id;
    private int valor;
    private LocalDate data;

    public Bombeta(int valor, String nombre, LocalDate data) {
        id=Bombeta.contador;
        contador++;
        this.data=data;
        this.nombre=nombre;
        this.valor = valor;
    }

    public int getValor() {
        return valor;
    }

    public String getNombre() {
        return nombre;
    }

    public LocalDate getData() {
        return data;
    }

    @Override
    public String toString() {
        return "Bombeta{" +
                "nombre='" + nombre + '\'' +
                ", id=" + id +
                ", valor=" + valor +
                ", data=" + data +
                '}';
    }

    @Override
    public int compareTo(Bombeta o) {
        int resultado = 0;
        if (this.valor<o.valor) resultado=1;
        else if (this.valor>o.valor)resultado=-1;
        return resultado;
    }
}
