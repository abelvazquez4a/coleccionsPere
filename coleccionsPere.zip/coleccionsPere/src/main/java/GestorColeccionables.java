import java.time.LocalDate;
import java.util.Iterator;

public class GestorColeccionables {
    public static void main(String[] args) {
        LlistaBombetes llistaBombetes = new LlistaBombetes();
        llistaBombetes.addBombeta(new Bombeta(10,"Wellinton", LocalDate.of(2019,1,5)));
        llistaBombetes.addBombeta(new Bombeta(500,"Antonio", LocalDate.of(2020,1,5)));
        llistaBombetes.addBombeta(new Bombeta(200,"Ana", LocalDate.of(2013,3,23)));
        System.out.println("\nArray original\n");
        llistaBombetes.mostrarBombetes();
        llistaBombetes.ordenarBombetes();
        System.out.println("\nDespués de ordenar por valor\n");
        llistaBombetes.mostrarBombetes();
        System.out.println("\nDespués de ordenar alfabéticamente\n");
        llistaBombetes.ordenarBombetesPerNom();
        llistaBombetes.mostrarBombetes();
        System.out.println("\nDespués de ordenar por fecha\n");
        llistaBombetes.ordenarBombetesPerData();
        llistaBombetes.mostrarBombetes();
        System.out.println("\n Probando iterator\n");
        Iterator iteratorLlistaBombetes = llistaBombetes.iterator();
        System.out.println("\n Con hasNext()");
        while (iteratorLlistaBombetes.hasNext()){
            System.out.println(iteratorLlistaBombetes.next());
        }
        System.out.println("\n Con For-each");
        iteratorLlistaBombetes=llistaBombetes.iterator();
        for (Bombeta b:llistaBombetes
             ) {
            System.out.println(iteratorLlistaBombetes.next());
        }
        System.out.println("\n Iterador per valor\n");
        Iterator<Bombeta> iteradorPerValorMin = llistaBombetes.iteradorPerValor(500.0);
        while (iteradorPerValorMin.hasNext()){
            System.out.println(iteradorPerValorMin.next());
        }

    }
}
